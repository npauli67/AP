#include <iostream>

using namespace std;

/*Deklaration von alle Rechenwegen*/

double Addition(double Zahl1, double Zahl2)
{
	return Zahl1 + Zahl2;
}

double Subtraktion(double Zahl1, double Zahl2)
{
	return Zahl1 - Zahl2;
}

double Multiplikation(double Zahl1, double Zahl2)
{
	return Zahl1 * Zahl2;
}

double Division(double Zahl1, double Zahl2)
{
	return Zahl1 / Zahl2;
}

/*Main Funktion mit Ein und Ausgaben*/
int main()
{
	double Zahl1;
	double Zahl2;

	cout << "Geben Sie ihre zwei Zahlen ein. (Reihenfolge Zahl1 Zahl2)\n";
	cin >> Zahl1;
	cin >> Zahl2;

	double A = Addition(Zahl1, Zahl2);
	double S = Subtraktion(Zahl1, Zahl2);
	double M = Multiplikation(Zahl1, Zahl2);
	double D = Division(Zahl1, Zahl2);

	cout << "\nDas Ergebnis der Addtion betraegt:" << A << "\nDas Ergebnis der Subtraktion betraegt:" << S << "\nDas Ergenis der Multiplikation betraegt:" << M << "\nDas Ergebnis der Division betraegt:" << D;

	return 0;
}